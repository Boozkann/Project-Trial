# Sovereign Risk PoC v2
- Adds 0–10 rating scores (10=best).
- Multi-country Streamlit dashboard (DEU,GRC,ARG,ESP,ITA default).
- Indicators fetched from World Bank API.
Generated: 2025-09-01
